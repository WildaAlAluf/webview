import 'package:flutter/material.dart';
import 'package:uaswebview/homepage.dart';
import 'package:uaswebview/homepage.dart';
import 'package:uaswebview/webview.dart';

void main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    ),
  );
}
